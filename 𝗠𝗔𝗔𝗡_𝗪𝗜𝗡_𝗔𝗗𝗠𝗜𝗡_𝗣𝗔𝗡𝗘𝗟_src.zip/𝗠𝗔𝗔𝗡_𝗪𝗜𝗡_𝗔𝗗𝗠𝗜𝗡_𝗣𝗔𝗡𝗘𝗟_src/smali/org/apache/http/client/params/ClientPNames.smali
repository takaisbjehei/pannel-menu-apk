.class public interface abstract Lorg/apache/http/client/params/ClientPNames;
.super Ljava/lang/Object;
.source "ClientPNames.java"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field public static final ALLOW_CIRCULAR_REDIRECTS:Ljava/lang/String;

.field public static final CONNECTION_MANAGER_FACTORY:Ljava/lang/String;

.field public static final CONNECTION_MANAGER_FACTORY_CLASS_NAME:Ljava/lang/String;

.field public static final COOKIE_POLICY:Ljava/lang/String;

.field public static final DEFAULT_HEADERS:Ljava/lang/String;

.field public static final DEFAULT_HOST:Ljava/lang/String;

.field public static final HANDLE_AUTHENTICATION:Ljava/lang/String;

.field public static final HANDLE_REDIRECTS:Ljava/lang/String;

.field public static final MAX_REDIRECTS:Ljava/lang/String;

.field public static final REJECT_RELATIVE_REDIRECT:Ljava/lang/String;

.field public static final VIRTUAL_HOST:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "http.protocol.max-redirects"

    sput-object v0, Lorg/apache/http/client/params/ClientPNames;->MAX_REDIRECTS:Ljava/lang/String;

    const-string v0, "http.protocol.handle-authentication"

    sput-object v0, Lorg/apache/http/client/params/ClientPNames;->HANDLE_AUTHENTICATION:Ljava/lang/String;

    const-string v0, "http.protocol.cookie-policy"

    sput-object v0, Lorg/apache/http/client/params/ClientPNames;->COOKIE_POLICY:Ljava/lang/String;

    const-string v0, "http.protocol.allow-circular-redirects"

    sput-object v0, Lorg/apache/http/client/params/ClientPNames;->ALLOW_CIRCULAR_REDIRECTS:Ljava/lang/String;

    const-string v0, "http.protocol.handle-redirects"

    sput-object v0, Lorg/apache/http/client/params/ClientPNames;->HANDLE_REDIRECTS:Ljava/lang/String;

    const-string v0, "http.virtual-host"

    sput-object v0, Lorg/apache/http/client/params/ClientPNames;->VIRTUAL_HOST:Ljava/lang/String;

    const-string v0, "http.default-headers"

    sput-object v0, Lorg/apache/http/client/params/ClientPNames;->DEFAULT_HEADERS:Ljava/lang/String;

    const-string v0, "http.connection-manager.factory-object"

    sput-object v0, Lorg/apache/http/client/params/ClientPNames;->CONNECTION_MANAGER_FACTORY:Ljava/lang/String;

    const-string v0, "http.default-host"

    sput-object v0, Lorg/apache/http/client/params/ClientPNames;->DEFAULT_HOST:Ljava/lang/String;

    const-string v0, "http.protocol.reject-relative-redirect"

    sput-object v0, Lorg/apache/http/client/params/ClientPNames;->REJECT_RELATIVE_REDIRECT:Ljava/lang/String;

    const-string v0, "http.connection-manager.factory-class-name"

    sput-object v0, Lorg/apache/http/client/params/ClientPNames;->CONNECTION_MANAGER_FACTORY_CLASS_NAME:Ljava/lang/String;

    return-void
.end method
