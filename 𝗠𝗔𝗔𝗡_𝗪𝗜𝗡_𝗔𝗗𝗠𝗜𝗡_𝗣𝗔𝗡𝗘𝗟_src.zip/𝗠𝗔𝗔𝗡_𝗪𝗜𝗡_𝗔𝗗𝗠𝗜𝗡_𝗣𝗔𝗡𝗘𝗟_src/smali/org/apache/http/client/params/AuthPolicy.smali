.class public final Lorg/apache/http/client/params/AuthPolicy;
.super Ljava/lang/Object;
.source "AuthPolicy.java"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field public static final BASIC:Ljava/lang/String;

.field public static final DIGEST:Ljava/lang/String;

.field public static final NTLM:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "NTLM"

    sput-object v0, Lorg/apache/http/client/params/AuthPolicy;->NTLM:Ljava/lang/String;

    const-string v0, "Digest"

    sput-object v0, Lorg/apache/http/client/params/AuthPolicy;->DIGEST:Ljava/lang/String;

    const-string v0, "Basic"

    sput-object v0, Lorg/apache/http/client/params/AuthPolicy;->BASIC:Ljava/lang/String;

    return-void
.end method

.method constructor <init>()V
    .locals 2

    .prologue
    .line 36
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Stub!"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
