.class public final Lorg/apache/http/client/params/CookiePolicy;
.super Ljava/lang/Object;
.source "CookiePolicy.java"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field public static final BEST_MATCH:Ljava/lang/String;

.field public static final BROWSER_COMPATIBILITY:Ljava/lang/String;

.field public static final NETSCAPE:Ljava/lang/String;

.field public static final RFC_2109:Ljava/lang/String;

.field public static final RFC_2965:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "rfc2109"

    sput-object v0, Lorg/apache/http/client/params/CookiePolicy;->RFC_2109:Ljava/lang/String;

    const-string v0, "netscape"

    sput-object v0, Lorg/apache/http/client/params/CookiePolicy;->NETSCAPE:Ljava/lang/String;

    const-string v0, "compatibility"

    sput-object v0, Lorg/apache/http/client/params/CookiePolicy;->BROWSER_COMPATIBILITY:Ljava/lang/String;

    const-string v0, "best-match"

    sput-object v0, Lorg/apache/http/client/params/CookiePolicy;->BEST_MATCH:Ljava/lang/String;

    const-string v0, "rfc2965"

    sput-object v0, Lorg/apache/http/client/params/CookiePolicy;->RFC_2965:Ljava/lang/String;

    return-void
.end method

.method constructor <init>()V
    .locals 2

    .prologue
    .line 36
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Stub!"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
