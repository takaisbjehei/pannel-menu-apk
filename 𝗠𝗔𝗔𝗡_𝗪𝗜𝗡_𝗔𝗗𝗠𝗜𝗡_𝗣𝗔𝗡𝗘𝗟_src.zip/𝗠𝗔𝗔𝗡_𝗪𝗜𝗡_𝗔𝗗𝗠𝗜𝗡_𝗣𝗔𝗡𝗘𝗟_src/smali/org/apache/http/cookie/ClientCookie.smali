.class public interface abstract Lorg/apache/http/cookie/ClientCookie;
.super Ljava/lang/Object;
.source "ClientCookie.java"

# interfaces
.implements Lorg/apache/http/cookie/Cookie;


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field public static final COMMENTURL_ATTR:Ljava/lang/String;

.field public static final COMMENT_ATTR:Ljava/lang/String;

.field public static final DISCARD_ATTR:Ljava/lang/String;

.field public static final DOMAIN_ATTR:Ljava/lang/String;

.field public static final EXPIRES_ATTR:Ljava/lang/String;

.field public static final MAX_AGE_ATTR:Ljava/lang/String;

.field public static final PATH_ATTR:Ljava/lang/String;

.field public static final PORT_ATTR:Ljava/lang/String;

.field public static final SECURE_ATTR:Ljava/lang/String;

.field public static final VERSION_ATTR:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "port"

    sput-object v0, Lorg/apache/http/cookie/ClientCookie;->PORT_ATTR:Ljava/lang/String;

    const-string v0, "comment"

    sput-object v0, Lorg/apache/http/cookie/ClientCookie;->COMMENT_ATTR:Ljava/lang/String;

    const-string v0, "version"

    sput-object v0, Lorg/apache/http/cookie/ClientCookie;->VERSION_ATTR:Ljava/lang/String;

    const-string v0, "domain"

    sput-object v0, Lorg/apache/http/cookie/ClientCookie;->DOMAIN_ATTR:Ljava/lang/String;

    const-string v0, "commenturl"

    sput-object v0, Lorg/apache/http/cookie/ClientCookie;->COMMENTURL_ATTR:Ljava/lang/String;

    const-string v0, "path"

    sput-object v0, Lorg/apache/http/cookie/ClientCookie;->PATH_ATTR:Ljava/lang/String;

    const-string v0, "discard"

    sput-object v0, Lorg/apache/http/cookie/ClientCookie;->DISCARD_ATTR:Ljava/lang/String;

    const-string v0, "expires"

    sput-object v0, Lorg/apache/http/cookie/ClientCookie;->EXPIRES_ATTR:Ljava/lang/String;

    const-string v0, "secure"

    sput-object v0, Lorg/apache/http/cookie/ClientCookie;->SECURE_ATTR:Ljava/lang/String;

    const-string v0, "max-age"

    sput-object v0, Lorg/apache/http/cookie/ClientCookie;->MAX_AGE_ATTR:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public abstract containsAttribute(Ljava/lang/String;)Z
.end method

.method public abstract getAttribute(Ljava/lang/String;)Ljava/lang/String;
.end method
