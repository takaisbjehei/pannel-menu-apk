.class public interface abstract Lorg/apache/http/auth/params/AuthPNames;
.super Ljava/lang/Object;
.source "AuthPNames.java"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field public static final CREDENTIAL_CHARSET:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "http.auth.credential-charset"

    sput-object v0, Lorg/apache/http/auth/params/AuthPNames;->CREDENTIAL_CHARSET:Ljava/lang/String;

    return-void
.end method
