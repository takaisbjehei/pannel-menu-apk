.class public interface abstract Lorg/apache/http/conn/params/ConnManagerPNames;
.super Ljava/lang/Object;
.source "ConnManagerPNames.java"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field public static final MAX_CONNECTIONS_PER_ROUTE:Ljava/lang/String;

.field public static final MAX_TOTAL_CONNECTIONS:Ljava/lang/String;

.field public static final TIMEOUT:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    const-string v0, "http.conn-manager.max-total"

    sput-object v0, Lorg/apache/http/conn/params/ConnManagerPNames;->MAX_TOTAL_CONNECTIONS:Ljava/lang/String;

    const-string v0, "http.conn-manager.max-per-route"

    sput-object v0, Lorg/apache/http/conn/params/ConnManagerPNames;->MAX_CONNECTIONS_PER_ROUTE:Ljava/lang/String;

    const-string v0, "http.conn-manager.timeout"

    sput-object v0, Lorg/apache/http/conn/params/ConnManagerPNames;->TIMEOUT:Ljava/lang/String;

    return-void
.end method
