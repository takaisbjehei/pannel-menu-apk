.class public Lcom/mizan/M4/ha;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static native i(I)B
.end method

.method public static native i(IBBBLjava/lang/Object;Ljava/lang/Object;)B
.end method

.method public static native i(IBLjava/lang/Object;)B
.end method

.method public static native i(ILjava/lang/Object;)B
.end method

.method public static native i(IC)C
.end method

.method public static native i(ILjava/lang/Object;)C
.end method

.method public static native i(ILjava/lang/Object;I)C
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;)C
.end method

.method public static native i(I)D
.end method

.method public static native i(ID)D
.end method

.method public static native i(IDD)D
.end method

.method public static native i(IDDD)D
.end method

.method public static native i(IDDDZ)D
.end method

.method public static native i(II)D
.end method

.method public static native i(ILjava/lang/Object;)D
.end method

.method public static native i(ILjava/lang/Object;D)D
.end method

.method public static native i(ILjava/lang/Object;F)D
.end method

.method public static native i(ILjava/lang/Object;I)D
.end method

.method public static native i(ILjava/lang/Object;II)D
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;)D
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;II)D
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)D
.end method

.method public static native i(IF)F
.end method

.method public static native i(IFF)F
.end method

.method public static native i(IFFF)F
.end method

.method public static native i(IFFFF)F
.end method

.method public static native i(IFFFFF)F
.end method

.method public static native i(IFFFFFF)F
.end method

.method public static native i(IFFFFFZ)F
.end method

.method public static native i(IFFFI)F
.end method

.method public static native i(IFFFLjava/lang/Object;)F
.end method

.method public static native i(IFFI)F
.end method

.method public static native i(IFFII)F
.end method

.method public static native i(IFFZ)F
.end method

.method public static native i(IFLjava/lang/Object;)F
.end method

.method public static native i(II)F
.end method

.method public static native i(IIFLjava/lang/Object;)F
.end method

.method public static native i(ILjava/lang/Object;)F
.end method

.method public static native i(ILjava/lang/Object;F)F
.end method

.method public static native i(ILjava/lang/Object;FF)F
.end method

.method public static native i(ILjava/lang/Object;FFF)F
.end method

.method public static native i(ILjava/lang/Object;FIFII)F
.end method

.method public static native i(ILjava/lang/Object;FLjava/lang/Object;)F
.end method

.method public static native i(ILjava/lang/Object;I)F
.end method

.method public static native i(ILjava/lang/Object;IF)F
.end method

.method public static native i(ILjava/lang/Object;II)F
.end method

.method public static native i(ILjava/lang/Object;III)F
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;)F
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;F)F
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FFLjava/lang/Object;)F
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;I)F
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IF)F
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;II)F
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)F
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FF)F
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)F
.end method

.method public static native i(I)I
.end method

.method public static native i(IBLjava/lang/Object;IILjava/lang/Object;I)I
.end method

.method public static native i(IBSLjava/lang/Object;I)I
.end method

.method public static native i(ICI)I
.end method

.method public static native i(ID)I
.end method

.method public static native i(IDD)I
.end method

.method public static native i(IDDD)I
.end method

.method public static native i(IF)I
.end method

.method public static native i(IFF)I
.end method

.method public static native i(II)I
.end method

.method public static native i(III)I
.end method

.method public static native i(IIID)I
.end method

.method public static native i(IIIF)I
.end method

.method public static native i(IIIFFF)I
.end method

.method public static native i(IIII)I
.end method

.method public static native i(IIIII)I
.end method

.method public static native i(IIIIIZ)I
.end method

.method public static native i(IIILjava/lang/Object;)I
.end method

.method public static native i(IILjava/lang/Object;)I
.end method

.method public static native i(IILjava/lang/Object;Ljava/lang/Object;)I
.end method

.method public static native i(IILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)I
.end method

.method public static native i(IILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)I
.end method

.method public static native i(IJJ)I
.end method

.method public static native i(ILjava/lang/Object;)I
.end method

.method public static native i(ILjava/lang/Object;F)I
.end method

.method public static native i(ILjava/lang/Object;FF)I
.end method

.method public static native i(ILjava/lang/Object;FFFFI)I
.end method

.method public static native i(ILjava/lang/Object;FFFFII)I
.end method

.method public static native i(ILjava/lang/Object;I)I
.end method

.method public static native i(ILjava/lang/Object;IF)I
.end method

.method public static native i(ILjava/lang/Object;II)I
.end method

.method public static native i(ILjava/lang/Object;IIF)I
.end method

.method public static native i(ILjava/lang/Object;III)I
.end method

.method public static native i(ILjava/lang/Object;IIII)I
.end method

.method public static native i(ILjava/lang/Object;IIILjava/lang/Object;)I
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;)I
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)I
.end method

.method public static native i(ILjava/lang/Object;IZ)I
.end method

.method public static native i(ILjava/lang/Object;J)I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;)I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;F)I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FF)I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;I)I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;II)I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IILjava/lang/Object;)I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IILjava/lang/Object;I)I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;)I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IZ)I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;F)I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;III)I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Z)I
.end method

.method public static native i(ILjava/lang/Object;Z)I
.end method

.method public static native i(ILjava/lang/Object;ZII)I
.end method

.method public static native i(ISBBBLjava/lang/Object;Ljava/lang/Object;IILjava/lang/Object;I)I
.end method

.method public static native i(I)J
.end method

.method public static native i(ID)J
.end method

.method public static native i(IJ)J
.end method

.method public static native i(IJJ)J
.end method

.method public static native i(IJJJ)J
.end method

.method public static native i(ILjava/lang/Object;)J
.end method

.method public static native i(ILjava/lang/Object;I)J
.end method

.method public static native i(ILjava/lang/Object;II)J
.end method

.method public static native i(ILjava/lang/Object;J)J
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;)J
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;I)J
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;II)J
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;J)J
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)J
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ZI)J
.end method

.method public static native i(I)Ljava/lang/Object;
.end method

.method public static native i(IB)Ljava/lang/Object;
.end method

.method public static native i(IC)Ljava/lang/Object;
.end method

.method public static native i(ID)Ljava/lang/Object;
.end method

.method public static native i(IDD)Ljava/lang/Object;
.end method

.method public static native i(IDDD)Ljava/lang/Object;
.end method

.method public static native i(IDDDLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(IF)Ljava/lang/Object;
.end method

.method public static native i(IFF)Ljava/lang/Object;
.end method

.method public static native i(IFFFF)Ljava/lang/Object;
.end method

.method public static native i(IFFFFLjava/lang/Object;FLjava/lang/Object;FLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(IFLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(II)Ljava/lang/Object;
.end method

.method public static native i(IIFFF)Ljava/lang/Object;
.end method

.method public static native i(IIFFFLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(IIFFFLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(III)Ljava/lang/Object;
.end method

.method public static native i(IIIIIZZ)Ljava/lang/Object;
.end method

.method public static native i(IIILjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(IIIZ)Ljava/lang/Object;
.end method

.method public static native i(IIIZI)Ljava/lang/Object;
.end method

.method public static native i(IILjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(IILjava/lang/Object;I)Ljava/lang/Object;
.end method

.method public static native i(IILjava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(IIS)Ljava/lang/Object;
.end method

.method public static native i(IIZ)Ljava/lang/Object;
.end method

.method public static native i(IIZLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(IJ)Ljava/lang/Object;
.end method

.method public static native i(IJJIFFI)Ljava/lang/Object;
.end method

.method public static native i(IJLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;B)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;BZLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;C)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;CC)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;D)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;DDDZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;DLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;F)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FF)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FFF)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FFFF)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FFFFF)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FFFFFFF)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FFFI)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FFFII)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FFFIZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FFFZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FFFZZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FFFZZF)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FFFZZFFF)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FFLjava/lang/Object;Ljava/lang/Object;FF)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FFZLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FI)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FILjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FILjava/lang/Object;I)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FIZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FIZF)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FIZFLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;FZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;I)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IC)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IF)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IFFIFFF)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IFFLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IFFZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;II)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IIC)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IIFF)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IIFIII)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;III)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IIII)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IIIILjava/lang/Object;Z)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IIILjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IIIZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IILjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IILjava/lang/Object;I)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IIZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;I)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;FZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;Z)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;ZZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;J)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;JI)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;JLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;JZZLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;JZZZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;F)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FF)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FFF)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FFFLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FFLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FI)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FIFIFIF)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;I)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;II)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;III)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IIIZZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IIIZZLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IILjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;J)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;JLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FF)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IIIIII)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IILjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FFF)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;J)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JZZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZJ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Z)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ZZ)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;S)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Z)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;ZILjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;ZLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;ZLjava/lang/Object;II)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;ZZI)Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;ZZZ)Ljava/lang/Object;
.end method

.method public static native i(IS)Ljava/lang/Object;
.end method

.method public static native i(IZ)Ljava/lang/Object;
.end method

.method public static native i(IZLjava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(IZLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public static native i(IBBLjava/lang/Object;)S
.end method

.method public static native i(IBILjava/lang/Object;)S
.end method

.method public static native i(IBSB)S
.end method

.method public static native i(ILjava/lang/Object;)S
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;)S
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;S)S
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Z)S
.end method

.method public static native i(IS)S
.end method

.method public static native i(I)V
.end method

.method public static native i(IB)V
.end method

.method public static native i(ID)V
.end method

.method public static native i(IFLjava/lang/Object;)V
.end method

.method public static native i(II)V
.end method

.method public static native i(IIII)V
.end method

.method public static native i(IIIILjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(IIIILjava/lang/Object;Ljava/lang/Object;I)V
.end method

.method public static native i(IIILjava/lang/Object;)V
.end method

.method public static native i(IIILjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(IILjava/lang/Object;)V
.end method

.method public static native i(IILjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(IJ)V
.end method

.method public static native i(ILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;B)V
.end method

.method public static native i(ILjava/lang/Object;BLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;BZLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;C)V
.end method

.method public static native i(ILjava/lang/Object;D)V
.end method

.method public static native i(ILjava/lang/Object;DD)V
.end method

.method public static native i(ILjava/lang/Object;DDDD)V
.end method

.method public static native i(ILjava/lang/Object;DDDDDDDDD)V
.end method

.method public static native i(ILjava/lang/Object;DDDDDDLjava/lang/Object;DDD)V
.end method

.method public static native i(ILjava/lang/Object;DDLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;F)V
.end method

.method public static native i(ILjava/lang/Object;FF)V
.end method

.method public static native i(ILjava/lang/Object;FFF)V
.end method

.method public static native i(ILjava/lang/Object;FFFF)V
.end method

.method public static native i(ILjava/lang/Object;FFFFFF)V
.end method

.method public static native i(ILjava/lang/Object;FFFFFFFLjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;FFFFIILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;FFFFLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;FFFFLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;FFFFZFFF)V
.end method

.method public static native i(ILjava/lang/Object;FFFI)V
.end method

.method public static native i(ILjava/lang/Object;FFFLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;FFFLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;FFI)V
.end method

.method public static native i(ILjava/lang/Object;FFLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;FI)V
.end method

.method public static native i(ILjava/lang/Object;FIF)V
.end method

.method public static native i(ILjava/lang/Object;FLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;FLjava/lang/Object;III)V
.end method

.method public static native i(ILjava/lang/Object;FLjava/lang/Object;IIILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;FLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;FLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;FZ)V
.end method

.method public static native i(ILjava/lang/Object;FZFF)V
.end method

.method public static native i(ILjava/lang/Object;FZI)V
.end method

.method public static native i(ILjava/lang/Object;I)V
.end method

.method public static native i(ILjava/lang/Object;IB)V
.end method

.method public static native i(ILjava/lang/Object;ID)V
.end method

.method public static native i(ILjava/lang/Object;IF)V
.end method

.method public static native i(ILjava/lang/Object;IFF)V
.end method

.method public static native i(ILjava/lang/Object;IFFFIFIFIF)V
.end method

.method public static native i(ILjava/lang/Object;IFI)V
.end method

.method public static native i(ILjava/lang/Object;IFZ)V
.end method

.method public static native i(ILjava/lang/Object;IFZZ)V
.end method

.method public static native i(ILjava/lang/Object;IFZZZ)V
.end method

.method public static native i(ILjava/lang/Object;II)V
.end method

.method public static native i(ILjava/lang/Object;IIF)V
.end method

.method public static native i(ILjava/lang/Object;III)V
.end method

.method public static native i(ILjava/lang/Object;IIIF)V
.end method

.method public static native i(ILjava/lang/Object;IIII)V
.end method

.method public static native i(ILjava/lang/Object;IIIIF)V
.end method

.method public static native i(ILjava/lang/Object;IIIII)V
.end method

.method public static native i(ILjava/lang/Object;IIIIII)V
.end method

.method public static native i(ILjava/lang/Object;IIIIIIII)V
.end method

.method public static native i(ILjava/lang/Object;IIIIZ)V
.end method

.method public static native i(ILjava/lang/Object;IIIJJLjava/lang/Object;Ljava/lang/Object;II)V
.end method

.method public static native i(ILjava/lang/Object;IIILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;IIILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZIZLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;IIJLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;IILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;IILjava/lang/Object;I)V
.end method

.method public static native i(ILjava/lang/Object;IILjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;IILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;IILjava/lang/Object;Z)V
.end method

.method public static native i(ILjava/lang/Object;IIZ)V
.end method

.method public static native i(ILjava/lang/Object;IIZIZLjava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;IJ)V
.end method

.method public static native i(ILjava/lang/Object;IJILjava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;JILjava/lang/Object;Ljava/lang/Object;FJLjava/lang/Object;Z)V
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;I)V
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;II)V
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;ILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;IZ)V
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;I)V
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;ZZ)V
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;ZZZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;ZZZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;Z)V
.end method

.method public static native i(ILjava/lang/Object;IZ)V
.end method

.method public static native i(ILjava/lang/Object;IZIZLjava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;IZLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;IZZII)V
.end method

.method public static native i(ILjava/lang/Object;J)V
.end method

.method public static native i(ILjava/lang/Object;JJ)V
.end method

.method public static native i(ILjava/lang/Object;JJLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;JLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;JLjava/lang/Object;JZZ)V
.end method

.method public static native i(ILjava/lang/Object;JLjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;JLjava/lang/Object;Ljava/lang/Object;Z)V
.end method

.method public static native i(ILjava/lang/Object;JLjava/lang/Object;ZZLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;D)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;F)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FF)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FFF)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FFFF)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FFFFFFFLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FFFILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FFLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FFLjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FFZ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FFZLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FLjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;FZ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;I)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IF)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IFFI)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IFFZ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;II)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IIFFLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IIFLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;III)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IIII)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IIIIII)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IIIIIIII)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IIILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IIZ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IJ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IJI)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IJLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;III)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;ILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;JJLjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;IILjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IZ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IZZ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;J)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;JI)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;JIIFLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;JJ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;JJJIIFLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;JLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;JLjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;JLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;D)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;DLjava/lang/Object;Z)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;F)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FF)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FFF)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FFIII)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FFIIIFFZ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FZZ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IF)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IIII)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IILjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IIZ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IJ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;Z)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IZ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IZI)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;J)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJDD)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJDDLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JLjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;F)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FF)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FFF)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FFFF)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FFFLjava/lang/Object;FFFZ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IFF)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IFFLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IIIIILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IILjava/lang/Object;I)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;J)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FFFFLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FIIIIZZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FIIIIZZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZJ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZJLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZI)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZZ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZZZZLjava/lang/Object;Ljava/lang/Object;ZZLjava/lang/Object;Ljava/lang/Object;IILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZDLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZI)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZIZ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZZ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZZLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZZLjava/lang/Object;FFLjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Z)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ZD)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ZI)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ZJZLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;III)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;ILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;JLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;JLjava/lang/Object;Z)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ZZ)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ZZLjava/lang/Object;ILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ZZLjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ZZLjava/lang/Object;Z)V
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ZZZ)V
.end method

.method public static native i(ILjava/lang/Object;S)V
.end method

.method public static native i(ILjava/lang/Object;SI)V
.end method

.method public static native i(ILjava/lang/Object;SLjava/lang/Object;I)V
.end method

.method public static native i(ILjava/lang/Object;SSI)V
.end method

.method public static native i(ILjava/lang/Object;Z)V
.end method

.method public static native i(ILjava/lang/Object;ZBLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;ZII)V
.end method

.method public static native i(ILjava/lang/Object;ZIIIF)V
.end method

.method public static native i(ILjava/lang/Object;ZIIII)V
.end method

.method public static native i(ILjava/lang/Object;ZILjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;ZLjava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;ZLjava/lang/Object;I)V
.end method

.method public static native i(ILjava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;ZLjava/lang/Object;Z)V
.end method

.method public static native i(ILjava/lang/Object;ZZ)V
.end method

.method public static native i(ILjava/lang/Object;ZZLjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;ZZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;ZZLjava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(ILjava/lang/Object;ZZZ)V
.end method

.method public static native i(ILjava/lang/Object;ZZZLjava/lang/Object;)V
.end method

.method public static native i(IS)V
.end method

.method public static native i(ISS)V
.end method

.method public static native i(IZ)V
.end method

.method public static native i(IZLjava/lang/Object;)V
.end method

.method public static native i(IZLjava/lang/Object;Ljava/lang/Object;)V
.end method

.method public static native i(I)Z
.end method

.method public static native i(IC)Z
.end method

.method public static native i(ID)Z
.end method

.method public static native i(IDDD)Z
.end method

.method public static native i(IF)Z
.end method

.method public static native i(IFF)Z
.end method

.method public static native i(IFFF)Z
.end method

.method public static native i(II)Z
.end method

.method public static native i(III)Z
.end method

.method public static native i(IILjava/lang/Object;ILjava/lang/Object;)Z
.end method

.method public static native i(IILjava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;)Z
.end method

.method public static native i(IIZ)Z
.end method

.method public static native i(IJ)Z
.end method

.method public static native i(ILjava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;C)Z
.end method

.method public static native i(ILjava/lang/Object;D)Z
.end method

.method public static native i(ILjava/lang/Object;DII)Z
.end method

.method public static native i(ILjava/lang/Object;F)Z
.end method

.method public static native i(ILjava/lang/Object;FF)Z
.end method

.method public static native i(ILjava/lang/Object;FFFF)Z
.end method

.method public static native i(ILjava/lang/Object;FFFFLjava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;FFLjava/lang/Object;Z)Z
.end method

.method public static native i(ILjava/lang/Object;FFZZZ)Z
.end method

.method public static native i(ILjava/lang/Object;FLjava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;FLjava/lang/Object;Ljava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;I)Z
.end method

.method public static native i(ILjava/lang/Object;IC)Z
.end method

.method public static native i(ILjava/lang/Object;IF)Z
.end method

.method public static native i(ILjava/lang/Object;II)Z
.end method

.method public static native i(ILjava/lang/Object;III)Z
.end method

.method public static native i(ILjava/lang/Object;IIII)Z
.end method

.method public static native i(ILjava/lang/Object;IILjava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;IJ)Z
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;I)Z
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;Z)Z
.end method

.method public static native i(ILjava/lang/Object;IZ)Z
.end method

.method public static native i(ILjava/lang/Object;J)Z
.end method

.method public static native i(ILjava/lang/Object;JF)Z
.end method

.method public static native i(ILjava/lang/Object;JII)Z
.end method

.method public static native i(ILjava/lang/Object;JJ)Z
.end method

.method public static native i(ILjava/lang/Object;JLjava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;F)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;I)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;II)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IILjava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;Ljava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;IZ)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;J)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IIF)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IIII)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IILjava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;J)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;FF)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;IZLjava/lang/Object;)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ZZ)Z
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Z)Z
.end method

.method public static native i(ILjava/lang/Object;Z)Z
.end method

.method public static native i(ILjava/lang/Object;ZZ)Z
.end method

.method public static native i(ILjava/lang/Object;ZZZ)Z
.end method

.method public static native i(IZLjava/lang/Object;Ljava/lang/Object;)Z
.end method

.method public static native i(I)[B
.end method

.method public static native i(IBILjava/lang/Object;)[B
.end method

.method public static native i(IC)[B
.end method

.method public static native i(II)[B
.end method

.method public static native i(III)[B
.end method

.method public static native i(IILjava/lang/Object;)[B
.end method

.method public static native i(IJI)[B
.end method

.method public static native i(ILjava/lang/Object;)[B
.end method

.method public static native i(ILjava/lang/Object;I)[B
.end method

.method public static native i(ILjava/lang/Object;II)[B
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;)[B
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;I)[B
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;II)[B
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)[B
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)[B
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;)[B
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)[B
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)[B
.end method

.method public static native i(ILjava/lang/Object;Z)[B
.end method

.method public static native i(IS)[B
.end method

.method public static native i(I)[C
.end method

.method public static native i(II)[C
.end method

.method public static native i(ILjava/lang/Object;)[C
.end method

.method public static native i(I)[D
.end method

.method public static native i(IDD)[D
.end method

.method public static native i(IDI)[D
.end method

.method public static native i(II)[D
.end method

.method public static native i(ILjava/lang/Object;)[D
.end method

.method public static native i(ILjava/lang/Object;DLjava/lang/Object;)[D
.end method

.method public static native i(ILjava/lang/Object;DLjava/lang/Object;I)[D
.end method

.method public static native i(ILjava/lang/Object;I)[D
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;)[D
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)[D
.end method

.method public static native i(I)[F
.end method

.method public static native i(IFLjava/lang/Object;F)[F
.end method

.method public static native i(IFLjava/lang/Object;Z)[F
.end method

.method public static native i(ILjava/lang/Object;)[F
.end method

.method public static native i(ILjava/lang/Object;FF)[F
.end method

.method public static native i(ILjava/lang/Object;FLjava/lang/Object;)[F
.end method

.method public static native i(ILjava/lang/Object;I)[F
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;)[F
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;F)[F
.end method

.method public static native i(I)[I
.end method

.method public static native i(ILjava/lang/Object;)[I
.end method

.method public static native i(ILjava/lang/Object;I)[I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;)[I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)[I
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Z)[I
.end method

.method public static native i(ILjava/lang/Object;)[J
.end method

.method public static native i(ILjava/lang/Object;I)[J
.end method

.method public static native i(I)[Ljava/lang/Object;
.end method

.method public static native i(II)[Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;)[Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;I)[Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;IILjava/lang/Object;)[Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;ILjava/lang/Object;)[Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;)[Ljava/lang/Object;
.end method

.method public static native i(ILjava/lang/Object;Ljava/lang/Object;I)[Ljava/lang/Object;
.end method

.method public static native i(IBSLjava/lang/Object;B)[S
.end method

.method public static native i(IBSLjava/lang/Object;Ljava/lang/Object;IB)[S
.end method

.method public static native i(ILjava/lang/Object;)[Z
.end method

.method public static native i(ILjava/lang/Object;I)[Z
.end method

.method public static native i(I)[[D
.end method

.method public static native i(IDD)[[D
.end method

.method public static native i(I)[[I
.end method

.method public static native i(ILjava/lang/Object;)[[I
.end method

.method public static native u()V
.end method
