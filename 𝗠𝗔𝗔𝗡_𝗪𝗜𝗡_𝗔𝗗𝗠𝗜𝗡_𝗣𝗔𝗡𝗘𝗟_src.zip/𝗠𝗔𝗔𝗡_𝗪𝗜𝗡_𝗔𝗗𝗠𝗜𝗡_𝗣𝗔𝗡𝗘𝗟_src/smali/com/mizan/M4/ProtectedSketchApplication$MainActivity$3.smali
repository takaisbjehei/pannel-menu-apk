.class public final Lcom/mizan/M4/ProtectedSketchApplication$MainActivity$3;
.super Ljava/lang/Object;


# static fields
.field public static final ov:Ljava/lang/String;

.field public static xFu:Ljava/lang/String;


# instance fields
.field public final Aanx:Z

.field public final CkCf:I

.field public final EHkrt:Ljava/lang/String;

.field public final Fdinh:I

.field public final bA:Z

.field public final qH:Z

.field public final rJ:Z

.field public final u:Ljava/lang/String;

.field public final v:Z

.field public final vqCI:Z


# direct methods
.method static constructor <clinit>()V
    .locals 9

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/UUID;->getMostSignificantBits()J

    move-result-wide v1

    invoke-virtual {v0}, Ljava/util/UUID;->getLeastSignificantBits()J

    move-result-wide v3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    const/16 v0, 0x10

    shl-long/2addr v5, v0

    const-wide/32 v7, 0xffff

    and-long/2addr v1, v7

    or-long/2addr v1, v5

    new-instance v0, Ljava/util/UUID;

    invoke-direct {v0, v1, v2, v3, v4}, Ljava/util/UUID;-><init>(JJ)V

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/mizan/M4/ProtectedSketchApplication$MainActivity$3;->ov:Ljava/lang/String;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;Ljava/lang/String;I)V
    .locals 1

    .prologue
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object p1, Lcom/mizan/M4/ProtectedSketchApplication$MainActivity$3;->ov:Ljava/lang/String;

    iput-object p1, p0, Lcom/mizan/M4/ProtectedSketchApplication$MainActivity$3;->u:Ljava/lang/String;

    iput-object p2, p0, Lcom/mizan/M4/ProtectedSketchApplication$MainActivity$3;->EHkrt:Ljava/lang/String;

    iput p3, p0, Lcom/mizan/M4/ProtectedSketchApplication$MainActivity$3;->CkCf:I

    and-int/lit8 p1, p3, 0x1

    const/4 p2, 0x0

    const/4 v0, 0x1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    iput-boolean p1, p0, Lcom/mizan/M4/ProtectedSketchApplication$MainActivity$3;->v:Z

    and-int/lit8 p1, p3, 0x2

    if-eqz p1, :cond_1

    const/4 p1, 0x1

    goto :goto_1

    :cond_1
    const/4 p1, 0x0

    :goto_1
    iput-boolean p1, p0, Lcom/mizan/M4/ProtectedSketchApplication$MainActivity$3;->rJ:Z

    and-int/lit8 p1, p3, 0x4

    if-eqz p1, :cond_2

    const/4 p1, 0x1

    goto :goto_2

    :cond_2
    const/4 p1, 0x0

    :goto_2
    iput-boolean p1, p0, Lcom/mizan/M4/ProtectedSketchApplication$MainActivity$3;->bA:Z

    and-int/lit8 p1, p3, 0x8

    if-eqz p1, :cond_3

    const/4 p1, 0x1

    goto :goto_3

    :cond_3
    const/4 p1, 0x0

    :goto_3
    iput-boolean p1, p0, Lcom/mizan/M4/ProtectedSketchApplication$MainActivity$3;->Aanx:Z

    and-int/lit8 p1, p3, 0x10

    if-eqz p1, :cond_4

    const/4 p1, 0x1

    goto :goto_4

    :cond_4
    const/4 p1, 0x0

    :goto_4
    iput-boolean p1, p0, Lcom/mizan/M4/ProtectedSketchApplication$MainActivity$3;->qH:Z

    and-int/lit8 p1, p3, 0x20

    if-eqz p1, :cond_5

    const/4 p2, 0x1

    :cond_5
    iput-boolean p2, p0, Lcom/mizan/M4/ProtectedSketchApplication$MainActivity$3;->vqCI:Z

    const/4 p1, 0x2

    iput p1, p0, Lcom/mizan/M4/ProtectedSketchApplication$MainActivity$3;->Fdinh:I

    return-void
.end method

.method public static ncczs(Ljava/lang/String;)V
    .locals 0

    return-void
.end method

.method public static native pucocqgeDc()Lcom/mizan/M4/ProtectedSketchApplication$MainActivity$3;
.end method
